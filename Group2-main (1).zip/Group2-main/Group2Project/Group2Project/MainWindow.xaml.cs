﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Group2Project.Models;
using Microsoft.EntityFrameworkCore;

namespace Group2Project
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// Appends a message to the on-screen log box.
        /// Used for tracking progress, warnings, and errors.
        private void Log(string msg)
        {
            LogBox.AppendText(msg + "\n");
        }


        //  LOAD PLAYERS FROM CSV
        //  - Reads Player_Info.csv
        //  - Skips aggregated "2TM", "3TM", "4TM", "TOT" rows
        //  - Inserts one row per TRUE team/season
        private async void LoadPlayersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using var context = new NbaContext();

                // Prevent double-importing. Table should only be populated once.
                if (context.Players.Any())
                {
                    Log("STOPPED: Players already exist. Import allowed only once.");
                    return;
                }

                Log("Loading Player_Info.csv...");

                // Read all rows except header
                var lines = File.ReadAllLines("Player_Info.csv").Skip(1);
                var players = new List<Player>();

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    var c = line.Split(',');
                    string team = c[3];

                    // Skip summary rows (2TM, 3TM, 4TM, TOT)
                    // These rows combine multiple teams and distort season mapping.
                    if (team.EndsWith("TM") || team == "TOT")
                        continue;

                    // Build Player entity from CSV columns
                    players.Add(new Player
                    {
                        PlayerId = c[0],
                        Player1 = c[1],
                        Age = ParseInt(c[2]),
                        Team = c[3],
                        Pos = c[4],
                        Season = ParseInt(c[5]),
                        Lg = c[6]
                    });
                }

                // Insert all players into the database
                context.Players.AddRange(players);
                await context.SaveChangesAsync();

                Log("Player_Info.csv imported successfully!");
            }
            catch (Exception ex)
            {
                Log("ERROR (Players): " + ex.Message);
            }
        }


        //  LOAD STATS FROM CSV — Correct Season Matching
        //
        //  - Reads Player_Stats.csv
        //  - Groups stat rows by player_id
        //  - CSV stats are newest→oldest, while player seasons are oldest→newest
        //    → Therefore stat rows are reversed to realign order
        //  - Matches each stat row with a specific Player row using PlayerKey+Season
        private async void LoadStatsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using var context = new NbaContext();

                // Ensure Players table is loaded first
                if (!context.Players.Any())
                {
                    Log("STOPPED: Load Players FIRST.");
                    return;
                }

                // Prevent duplicate stats load
                if (context.PlayerStats.Any())
                {
                    Log("STOPPED: PlayerStats already imported.");
                    return;
                }

                Log("Building Player season list...");

                // Build dictionary:
                //   Key: player_id
                //   Value: list of Player rows for that player, sorted oldest → newest
                var playerSeasons = context.Players
                    .OrderBy(p => p.Season)
                    .GroupBy(p => p.PlayerId)
                    .ToDictionary(
                        g => g.Key,
                        g => g.ToList()
                    );

                Log("Loading Player_Stats.csv...");

                var statLines = File.ReadAllLines("Player_Stats.csv").Skip(1);
                var stats = new List<PlayerStat>();

                // Group stat rows by player_id
                var groupedStats = statLines
                    .Select(line => line.Split(','))
                    .GroupBy(c => c[0])
                    .ToDictionary(
                        g => g.Key,
                        g => g.ToList()
                    );

                // Process each player's stats
                foreach (var pid in groupedStats.Keys)
                {
                    // If player_id does not exist in Players table, skip
                    if (!playerSeasons.ContainsKey(pid))
                        continue;

                    // Player seasons sorted oldest → newest
                    var seasons = playerSeasons[pid]
                        .OrderBy(s => s.Season)
                        .ToList();

                    var playerStats = groupedStats[pid];

                    // CSV stats sorted newest → oldest, so reverse to align with season order
                    playerStats.Reverse();

                    // Avoid index overflow
                    int count = Math.Min(seasons.Count, playerStats.Count);

                    for (int i = 0; i < count; i++)
                    {
                        var c = playerStats[i];      // stat row
                        var seasonRow = seasons[i]; // matching Player row

                        try
                        {
                            // Build PlayerStat object
                            var stat = new PlayerStat
                            {
                                PlayerId = pid,
                                PlayerKey = seasonRow.PlayerKey,  // Correct FK link
                                Season = seasonRow.Season,        // Ensures correct season assignment

                                G = ParseInt(c[1]),
                                Gs = ParseInt(c[2]),
                                Mp = ParseDouble(c[3]),
                                Fg = ParseInt(c[4]),
                                Fga = ParseInt(c[5]),
                                FgPercent = ParseDouble(c[6]),
                                X3p = ParseInt(c[7]),
                                X3pa = ParseInt(c[8]),
                                X3pPercent = ParseDouble(c[9]),
                                X2p = ParseInt(c[10]),
                                X2pa = ParseInt(c[11]),
                                X2pPercent = ParseDouble(c[12]),
                                EFgPercent = ParseDouble(c[13]),
                                Ft = ParseInt(c[14]),
                                Fta = ParseInt(c[15]),
                                FtPercent = ParseDouble(c[16]),
                                Orb = ParseDouble(c[17]),
                                Drb = ParseDouble(c[18]),
                                Trb = ParseDouble(c[19]),
                                Ast = ParseDouble(c[20]),
                                Stl = ParseDouble(c[21]),
                                Blk = ParseDouble(c[22]),
                                Tov = ParseDouble(c[23]),
                                Pf = ParseDouble(c[24]),
                                Pts = ParseInt(c[25]),
                                TrpDbl = ParseDouble(c[26])
                            };

                            stats.Add(stat);
                        }
                        catch (Exception ex)
                        {
                            // Log row-level parsing errors but continue loading
                            Log($"ERROR parsing stats for {pid}: {ex.Message}");
                        }
                    }
                }

                // Save all stat rows
                context.PlayerStats.AddRange(stats);
                await context.SaveChangesAsync();

                Log("Player_Stats.csv imported successfully!");
            }
            catch (Exception ex)
            {
                Log("ERROR (Stats): " + ex.Message);
            }
        }


        // SAFELY PARSE NUMBERS
        // Returns null if parsing fails, preventing crashes.
        private int? ParseInt(string s) =>
            int.TryParse(s, out int v) ? v : null;

        private double? ParseDouble(string s) =>
            double.TryParse(s, out double v) ? v : null;
    }
}
